# UNICODE-ASSIGNMENTS

Memory game using html,css,javascript

When starting the game on your laptops open the homepage first which will take you to the gamepage

